# ES32F065x Device Release Note

## V1.00 2018-12-26

1. First release


## V1.01 2019-03-25

1. Delete TIMER alias
2. Change TEMP to TSENSE